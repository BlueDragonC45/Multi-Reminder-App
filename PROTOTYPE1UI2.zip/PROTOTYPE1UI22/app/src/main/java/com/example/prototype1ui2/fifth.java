package com.example.prototype1ui2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class fifth extends AppCompatActivity {
    private Button but5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth);

        but5 = (Button) findViewById(R.id.but5);
        but5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSixth();
            }
        });
    }
    public void openSixth() {
        Intent intent = new Intent(this, sixth.class);
        startActivity(intent);
    }
}
