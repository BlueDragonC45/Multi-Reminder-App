package com.example.prototype1ui2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class second extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }

      public void defineButtons(){
        findViewById(R.id.but2).setOnClickListener(buttonClickListener);
        findViewById(R.id.but3).setOnClickListener(buttonClickListener);
        findViewById(R.id.but4).setOnClickListener(buttonClickListener);
        findViewById(R.id.but5).setOnClickListener(buttonClickListener);


      }

      private View.OnClickListener buttonClickListener = new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              switch (v.getId()){
                  case R.id.but2:
                      Intent intent = new Intent(second.this, third.class);
                      break;
                  case R.id.but3:
                      Intent intent1  = new Intent(second.this, third.class);
                      break;
                  case R.id.but4:
                      Intent intent2 = new Intent(second.this, third.class);
                      break;
                  case R.id.but5:
                      Intent intent3 = new Intent(second.this, sixth.class);
                      break;


              }
          }
      };
}